export class CreateReportDto {
    message: string;
    isOpen: boolean;
    date: Date;
    commentId: string;
  }
  