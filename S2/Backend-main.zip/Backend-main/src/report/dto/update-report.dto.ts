export class UpdateReportDto {
  message?: string;
  isOpen?: boolean;
  date?: Date;
  commentId?: string;
}
  