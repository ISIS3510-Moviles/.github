export class UpdateFoodScheduleDto {
  name?: string;
  isActual?: boolean;
  freeTimesIds?: string[];
  userId?: string;
}
