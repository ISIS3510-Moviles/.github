export class CreateFoodTagDto {
  name: string;
  description: string;
}
