export class UpdateFoodTagDto {
  name?: string;
  description?: string;
}
