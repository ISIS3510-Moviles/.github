export class CreateBadgeDto {
    name: string;
    date?: Date;
    icon: string;
    description: string;
    usersIds?: string[];
  }
  