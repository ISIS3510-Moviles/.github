export class UpdateBadgeDto {
    name?: string;
    date?: Date;
    icon?: string;
    description?: string;
    usersIds?: string[];
  }
  