export class CreateDietaryTagDto {
  name: string;
  description: string;
}
