export class UpdateDietaryTagDto {
  name?: string;
  description?: string;
}
