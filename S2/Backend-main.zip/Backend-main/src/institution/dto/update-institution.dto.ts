export class UpdateInstitutionDto {
  name?: string;
  description?: string;
  buildingsIds?: string[];
  membersIds?: string[];
}
