export class CreateVisitDto {
  date: Date;
  visitorId: string;
  vendorId: string;
}
