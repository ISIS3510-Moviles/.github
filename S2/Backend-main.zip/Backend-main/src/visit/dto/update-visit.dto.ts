export class UpdateVisitDto {
  date?: Date;
  visitorId?: string;
  vendorId?: string;
}
