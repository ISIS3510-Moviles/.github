export class UpdateAlertDto {
  message?: string;
  date?: Date;
  icon?: string;
  votes?: number;
  restaurantId?: string;
  publisherId?: string;
}