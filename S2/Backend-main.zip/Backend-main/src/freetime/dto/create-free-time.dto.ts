export class CreateFreeTimeDto {
    startHour: string;
    endHour: string;
    tagsIds?: string[];
    scheduleId?: string;
  }
  