export class UpdateIngredientDto {
    name?: string;
    description?: string;
    productsIds?: string[];
    image?: string;
  }
  