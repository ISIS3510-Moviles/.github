export class CreateCampusBuildingDto {
    name: string;
    shortName: string;
    latitude: number;
    longitude: number;
    institutionId?: string;
  }
  