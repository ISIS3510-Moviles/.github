import admin from 'firebase-admin';
export default admin;
